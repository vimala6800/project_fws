export interface AddUser {
  id: string,
  userName: string ,
  email: string ;
  phoneNumber: string ,
  role: string 
}
export interface Role {
  id: string,
  name: string
}
