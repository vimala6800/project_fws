export interface Bench {
  benchID: string;
  partnerName: string;
  partnerID: any;
  noOfResource: number;
  skillSet: string;
  ratePerHrUSD: number;
  yearsOfExperience: string;
}
