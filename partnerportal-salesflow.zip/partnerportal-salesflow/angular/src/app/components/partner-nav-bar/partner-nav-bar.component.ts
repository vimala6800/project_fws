import { Component } from '@angular/core';

@Component({
  selector: 'app-partner-nav-bar',
  templateUrl: './partner-nav-bar.component.html',
  styleUrls: ['./partner-nav-bar.component.scss']
})
export class PartnerNavBarComponent {

}
