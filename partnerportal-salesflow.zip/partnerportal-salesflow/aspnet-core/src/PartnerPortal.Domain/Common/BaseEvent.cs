﻿using MediatR;

namespace PartnerPortal.Domain.Common
{
    public abstract class BaseEvent : INotification
    {
    }
}
