export class Constants {
  public static readonly USER_KEY: string = "userInfo";
  public static readonly BASE_URL: string = "https://localhost:7184"
}
