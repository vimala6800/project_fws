export interface Register{
  id: string;
    userName:string;
    email:string;
  phoneNumber: string;
  
}
