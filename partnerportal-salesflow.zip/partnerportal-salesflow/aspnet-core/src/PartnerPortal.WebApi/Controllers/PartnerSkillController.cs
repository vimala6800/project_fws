﻿namespace PartnerPortal.WebApi.Controllers
{
    public class PartnerSkillController
    {
    }
}
