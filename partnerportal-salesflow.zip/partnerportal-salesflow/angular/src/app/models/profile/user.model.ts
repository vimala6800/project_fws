export interface User {
  id: string;
  userName: string;
  emailId: string;
  companyName: string;
  address: string;
  contactNumber: string;
  password: string;
}
