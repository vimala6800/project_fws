﻿//using CsvHelper.Configuration;
//using PartnerPortal.Application.TodoLists.Queries.ExportTodos;
//using System;
//using System.Collections.Generic;
//using System.Globalization;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace PartnerPortal.Infrastructure.Files.Maps
//{
//    public class SkillsRecordMap : ClassMap<SkillsRecord>
//    {
//        public SkillsRecordMap() {
//            AutoMap(CultureInfo.InvariantCulture);
//            Map(m => m.SkillName).ConvertUsing(c=> c.SkillName );
//        }
//    }
//}
