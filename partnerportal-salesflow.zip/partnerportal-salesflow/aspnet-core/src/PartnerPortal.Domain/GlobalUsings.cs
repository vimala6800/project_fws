﻿global using PartnerPortal.Domain.Common;
global using PartnerPortal.Domain.Entities;
global using PartnerPortal.Domain.Enums;
global using PartnerPortal.Domain.Events;
global using PartnerPortal.Domain.Exceptions;
global using PartnerPortal.Domain.ValueObjects;