import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-req',
  templateUrl: './edit-req.component.html',
  styleUrls: ['./edit-req.component.scss']
})
export class EditReqComponent {

}
