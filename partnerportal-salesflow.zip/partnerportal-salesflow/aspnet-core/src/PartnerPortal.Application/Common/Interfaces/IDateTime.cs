﻿namespace PartnerPortal.Application.Common.Interfaces
{
    public interface IDateTime
    {
        DateTime Now { get; }
    }

}
