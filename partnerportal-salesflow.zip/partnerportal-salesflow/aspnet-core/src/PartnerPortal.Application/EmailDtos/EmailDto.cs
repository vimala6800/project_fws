﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartnerPortal.Application.EmailDtos
{
    public class EmailDto
    {
        
        public string? MessageTemplate { get; set; }
    }
}
