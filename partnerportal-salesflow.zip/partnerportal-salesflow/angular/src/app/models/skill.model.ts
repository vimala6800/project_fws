export interface Skill {
  skillID: string;
  skillName: string;
}
