namespace PartnerPortal.Domain.Entities.BindingModel
{
	public class AddRoleBindingModel
	{
		//public string id { get; set; }
		public string Role { get; set; }
	}

}