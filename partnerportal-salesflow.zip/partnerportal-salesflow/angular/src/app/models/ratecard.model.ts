export interface RateCards {
  rateCardId:string;
  skillID:string;
  minYrExperience: string;
  maxYrExperience: string;
  ratePerHrUSD: string;
}


