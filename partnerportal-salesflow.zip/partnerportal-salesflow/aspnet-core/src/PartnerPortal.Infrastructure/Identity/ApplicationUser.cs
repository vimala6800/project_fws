﻿using Microsoft.AspNetCore.Identity;

namespace PartnerPortal.Infrastructure.Identity
{
	public class ApplicationUser : IdentityUser
	{
	}
}
